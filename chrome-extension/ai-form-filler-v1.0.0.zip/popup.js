// Popup script for AI Form Filler Chrome Extension
// Handles UI interactions and settings management

class PopupManager {
  constructor() {
    this.initializeElements();
    this.loadSettings();
    this.attachEventListeners();
    this.updateFieldCount();
  }

  initializeElements() {
    this.elements = {
      systemPrompt: document.getElementById('systemPrompt'),
      apiKey: document.getElementById('apiKey'),
      savePrompt: document.getElementById('savePrompt'),
      saveApiKey: document.getElementById('saveApiKey'),
      testConnection: document.getElementById('testConnection'),
      fillForms: document.getElementById('fillForms'),
      status: document.getElementById('status'),
      fieldCount: document.getElementById('fieldCount'),
      promptCharCount: document.getElementById('promptCharCount'),
      openOptions: document.getElementById('openOptions')
    };
  }

  attachEventListeners() {
    // Save system prompt
    this.elements.savePrompt.addEventListener('click', () => {
      this.saveSystemPrompt();
    });

    // Save API key
    this.elements.saveApiKey.addEventListener('click', () => {
      this.saveApiKey();
    });

    // Test API connection
    this.elements.testConnection.addEventListener('click', () => {
      this.testConnection();
    });

    // Fill forms
    this.elements.fillForms.addEventListener('click', () => {
      this.fillForms();
    });

    // Open options page
    this.elements.openOptions.addEventListener('click', () => {
      chrome.runtime.openOptionsPage();
    });

    // Character count for system prompt
    this.elements.systemPrompt.addEventListener('input', () => {
      this.updateCharCount();
    });

    // Auto-save system prompt on change (debounced)
    let promptTimeout;
    this.elements.systemPrompt.addEventListener('input', () => {
      clearTimeout(promptTimeout);
      promptTimeout = setTimeout(() => {
        this.saveSystemPrompt(false); // Silent save
      }, 1000);
    });

    // Auto-save API key on change (debounced)
    let apiKeyTimeout;
    this.elements.apiKey.addEventListener('input', () => {
      clearTimeout(apiKeyTimeout);
      apiKeyTimeout = setTimeout(() => {
        this.saveApiKey(false); // Silent save
      }, 1000);
    });
  }

  async loadSettings() {
    try {
      // Load system prompt from sync storage
      const syncData = await chrome.storage.sync.get(['systemPrompt']);
      if (syncData.systemPrompt) {
        this.elements.systemPrompt.value = syncData.systemPrompt;
        this.updateCharCount();
      }

      // Load API key from local storage (more secure)
      const localData = await chrome.storage.local.get(['apiKey']);
      if (localData.apiKey) {
        this.elements.apiKey.value = localData.apiKey;
      }

    } catch (error) {
      console.error('Error loading settings:', error);
      this.showStatus('Error loading settings', 'error');
    }
  }

  async saveSystemPrompt(showFeedback = true) {
    try {
      const prompt = this.elements.systemPrompt.value.trim();
      
      if (!prompt) {
        if (showFeedback) {
          this.showStatus('Please enter a system prompt', 'error');
        }
        return;
      }

      await chrome.storage.sync.set({ systemPrompt: prompt });
      
      if (showFeedback) {
        this.showStatus('System prompt saved successfully', 'success');
      }
    } catch (error) {
      console.error('Error saving system prompt:', error);
      this.showStatus('Error saving system prompt', 'error');
    }
  }

  async saveApiKey(showFeedback = true) {
    try {
      const apiKey = this.elements.apiKey.value.trim();
      
      if (!apiKey) {
        if (showFeedback) {
          this.showStatus('Please enter an API key', 'error');
        }
        return;
      }

      if (!apiKey.startsWith('sk-ant-')) {
        if (showFeedback) {
          this.showStatus('API key should start with "sk-ant-"', 'error');
        }
        return;
      }

      await chrome.storage.local.set({ apiKey: apiKey });
      
      if (showFeedback) {
        this.showStatus('API key saved successfully', 'success');
      }
    } catch (error) {
      console.error('Error saving API key:', error);
      this.showStatus('Error saving API key', 'error');
    }
  }

  async testConnection() {
    try {
      const apiKey = this.elements.apiKey.value.trim();
      
      if (!apiKey) {
        this.showStatus('Please enter an API key first', 'error');
        return;
      }

      this.elements.testConnection.disabled = true;
      this.elements.testConnection.textContent = 'Testing...';
      this.showStatus('Testing API connection...', 'info');

      // Send test request to background script
      const response = await new Promise((resolve) => {
        chrome.runtime.sendMessage({
          action: 'testConnection',
          apiKey: apiKey
        }, resolve);
      });

      if (response.success) {
        this.showStatus('✅ API connection successful!', 'success');
      } else {
        this.showStatus(`❌ Connection failed: ${response.error}`, 'error');
      }

    } catch (error) {
      console.error('Error testing connection:', error);
      this.showStatus('Error testing connection', 'error');
    } finally {
      this.elements.testConnection.disabled = false;
      this.elements.testConnection.textContent = 'Test Connection';
    }
  }

  async fillForms() {
    console.log('🚀 Fill Forms button clicked');
    
    // Get the current tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    console.log('📄 Current tab:', tab.url);
    
    if (!tab) {
      console.error('❌ No active tab found');
      this.showStatus('No active tab found', 'error');
      return;
    }

    // Get settings
    const settings = await chrome.storage.sync.get(['systemPrompt']);
    const localStorage = await chrome.storage.local.get(['apiKey']);
    
    console.log('⚙️ Settings loaded:', { 
      hasPrompt: !!settings.systemPrompt, 
      hasApiKey: !!localStorage.apiKey 
    });

    if (!settings.systemPrompt || !localStorage.apiKey) {
      console.error('❌ Missing configuration');
      this.showStatus('Please configure your API key and system prompt first', 'error');
      return;
    }

    try {
      this.showStatus('Detecting form fields...', 'info');
      console.log('📨 Sending message to content script...');
      
      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'fillForms',
        systemPrompt: settings.systemPrompt,
        apiKey: localStorage.apiKey
      });
      
      console.log('📨 Response from content script:', response);
      
      if (response && response.success) {
        this.showStatus('Forms filled successfully!', 'success');
      } else {
        this.showStatus(`Error: ${response?.error || 'Unknown error'}`, 'error');
      }
    } catch (error) {
      console.error('❌ Error sending message to content script:', error);
      this.showStatus(`Error: ${error.message}`, 'error');
    }
  }

  async updateFieldCount() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (!tab) {
        this.elements.fieldCount.textContent = 'No active tab';
        return;
      }

      // Check if we can access the tab (not a chrome:// or extension page)
      if (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
        this.elements.fieldCount.textContent = 'Cannot access this page';
        return;
      }

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'getFieldCount'
      });

      if (response && typeof response.count === 'number') {
        this.elements.fieldCount.textContent = `Found ${response.count} fillable fields`;
        
        // Enable/disable fill button based on field count
        this.elements.fillForms.disabled = response.count === 0;
        
        if (response.count === 0) {
          this.elements.fillForms.textContent = 'No Fields Found';
        } else {
          this.elements.fillForms.textContent = '🚀 Fill Forms on This Page';
        }
      } else {
        this.elements.fieldCount.textContent = 'Unable to scan fields';
      }

    } catch (error) {
      console.error('Error getting field count:', error);
      this.elements.fieldCount.textContent = 'Page not ready - please refresh';
      this.elements.fillForms.disabled = true;
    }
  }

  updateCharCount() {
    const current = this.elements.systemPrompt.value.length;
    const max = 2000;
    this.elements.promptCharCount.textContent = `${current}/${max}`;
    
    if (current > max * 0.9) {
      this.elements.promptCharCount.style.color = '#d73027';
    } else if (current > max * 0.7) {
      this.elements.promptCharCount.style.color = '#fc8d59';
    } else {
      this.elements.promptCharCount.style.color = '#666';
    }
  }

  showStatus(message, type = 'info') {
    this.elements.status.textContent = message;
    this.elements.status.className = `status ${type}`;
    this.elements.status.classList.remove('hidden');

    // Auto-hide after 5 seconds for success messages
    if (type === 'success') {
      setTimeout(() => {
        this.elements.status.classList.add('hidden');
      }, 5000);
    }
  }
}

// Initialize popup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new PopupManager();
});

// Handle popup reopening
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    // Popup became visible, update field count
    setTimeout(() => {
      if (window.popupManager) {
        window.popupManager.updateFieldCount();
      }
    }, 100);
  }
});

// Store global reference
document.addEventListener('DOMContentLoaded', () => {
  window.popupManager = new PopupManager();
});
